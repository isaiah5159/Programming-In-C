/* instructor provided C code file for lab5 */

#include <stdio.h>

long transitions(long i); /* you will implement this in assembler */

main()
{
		long i, cnt;
		
		printf("Enter an integer: ");
		scanf("%ld", &i);
		cnt = transitions(i);
		/* use %ld since we are dealing with longs */
		printf("%ld has %ld transitions.\n", i, cnt);
} 
