#include <math.h>
#include <stdio.h>

/* Author: Isaiah Green */

#define Knots2fps 1.687809855643 /* knot feet per second */

double fps(short speed)
{

		return(Knots2fps *speed);
}

int main(void)
{

		short air_speed;

		printf("Please enter the airspeed(knots): \n");
		scanf("%hd", &air_speed);
		printf("airspeed = %lf\n", fps(air_speed));
}
