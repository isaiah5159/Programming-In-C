#include <math.h>
#include <stdio.h>

/* Author: Isaiah Green */

#define M_PI 3.14159265359070323846 /* pi */

double Radians(short heading)
{

		return( heading * M_PI/180.0);
}

int main(void)
{

		short h;

		printf("Please enter the heading(degrees): \n");
		scanf("%hd", &h);
		printf("Heading = %hd\n", h);
		printf("The radian is: %lf\n", Radians(h));
}
