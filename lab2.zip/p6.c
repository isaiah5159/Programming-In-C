#include <math.h>
#include <stdio.h>

/* Author: Isaiah Green */

#define Knots2fps 1.687809855643 /* knot feet per second */
#define M_PI 3.14159265359070323846 /* pi */
#define time 60

double Radians(short heading)
{

		return(heading * M_PI/180.0);
}

double fps(short speed)
{

		return(Knots2fps *speed);	
}

double velY(double speed,short head)
{

		double velocity;
		
		velocity = speed *cos(Radians(head));

		printf("The velocity in Y is: %lf\n", velocity);
		return(velocity);
}

double velX(double speed,short head)
{

		double vel;
		
		vel = speed *sin(Radians(head));

		printf("The velocity in X is: %lf\n", vel);
		return(vel);
}


double ypos(double ve, int t)
{

		double y_position=0;
		
		y_position = y_position + ve * t;
		
		return(lround(y_position));
}

double xpos(double v, int t)
{

		double x_position=0;
		
		x_position = x_position + v * t;
		
		return(lround(x_position));
}

int main(void)
{

		short h, air_speed;
		double vy, vx;

		printf("Please enter the heading(degrees): \n");
		scanf("%hd", &h);
		printf("Heading = %hd\n", h);

		printf("Please enter the airspeed(knots): \n");
		scanf("%hd", &air_speed);
		printf("airspeed = %lf\n", fps(air_speed));

		vy = velY(fps(air_speed), h);
		vx = velX(fps(air_speed), h);

		ypos(vy,time);
		printf("yposition = %i\n", ypos(vy,time));
		xpos(vx,time);
		printf("xposition = %i\n", xpos(vx,time));
}
