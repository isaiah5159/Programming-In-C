#include "libatc.h"
#include <math.h>
#include <stdio.h>

/* Author: Isaiah Green */

#define Knots2fps 1.687809855643 /* knot feet per second */
#define M_PI 3.14159265359070323846 /* pi */
#define time 60
#define MFX (380*5280)
#define MFY (280*5280)

double Radians(short heading)
{
		return(heading * M_PI/180.0);
}

double fps(short speed)
{
		return(Knots2fps *speed);	
}

double velY(double speed,short head)
{
		double velocity;
		
		velocity = speed *cos(Radians(head));
		
		return(velocity);
}

double velX(double speed,short head)
{
		double vel;
		
		vel = speed *sin(Radians(head));
		
		return(vel);
}

int dist(double ve, int t)
{
		int dz;
		
		dz = lround(ve * t);

		printf("The distance in y is: %i\n", dz);
		return(dz);
}

int g_x(int xdis)
{
		int gx,c,offX;
		
		c = 1 + (al_max_X()  - al_min_X() );
		offX = xdis*c/MFX;
		gx = al_min_X()  + offX;
		
		printf("gx = %d\n",gx);
		return(gx);
}

int g_y(int ydis)
{
		int gy,r,offY;
		
		r = 1 + (al_max_Y() - al_min_Y());
		offY = ydis*r/MFY;
		gy = al_max_Y() - offY;
		
		printf("gy = %d\n",gy);
		return(gy);
}

int main(void)
{

		short h, air_speed;
		double vy, vx,row,col,result;
		int offsetX,offsetY, gx, gy,x=1000000,y=1000000;


		printf("Please enter the heading(degrees): \n");
		scanf("%hd", &h);
		printf("Heading = %hd\n", h);

		printf("Please enter the airspeed(knots): \n");
		scanf("%hd", &air_speed);
		printf("airspeed = %lf\n", fps(air_speed));

		vy = velY(fps(air_speed), h);
		vx = velX(fps(air_speed), h);

		y += dist(vy,time);
		x += dist(vx,time);

		g_x(x);
		g_y(y);
}
