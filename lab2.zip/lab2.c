#include "libatc.h"
#include <math.h>
#include <stdio.h>

/* Author: Isaiah Green */

#define Knots2fps 1.687809855643 /* knot feet per second */
#define M_PI 3.14159265359070323846 /* pi */
#define maxSign 15 /* max callsign you need */
#define time 60 /* delta time */
#define MFX (380*5280)/* x boundary for graphics */
#define MFY (280*5280)/* y boundary for graphics */

/*lab2 2>errs < 2jets.input*/

/* calculates degrees to radians */
double Radians(short heading)
{

		return(heading * M_PI/180.0);
}

/* calulates the fps/speed */
double fps(short speed)
{

		return(Knots2fps *speed);	
}

/* calulates the velocity of y direction */
double velY(double speed,short head)
{
		double velocity;
		
		velocity = speed *cos(Radians(head));
		
		return(velocity);
}

/* calulates the velocity of x direction */
double velX(double speed,short head)
{
		double vel;
		
		vel = speed *sin(Radians(head));
		
		return(vel);
}

/* calculates the distance for x and y direction*/
int dist(double ve, int t)
{
		int dz;
		
		dz = lround(ve * t);
		
		return(dz);
}

/* calculates the gx for graphics */
int g_x(int xdis)
{
		int gx,c,offX;
		
		c = 1 + (al_max_X()  - al_min_X() );
		offX = xdis*c/MFX;
		gx = al_min_X()  + offX;
		
		/*printf("gx = %d\n",gx);*/
		return(gx);
}

/* calulates the gy for graphics */
int g_y(int ydis)
{
		int gy,r,offY;
		
		r = 1 + (al_max_Y() - al_min_Y());
		offY = ydis*r/MFY;
		gy = al_max_Y() - offY;
		
		/*printf("gy = %d\n",gy);*/
		return(gy);
}

/* calulates the altitude/flight level */
int Flightlevel(int alt)
{
		int dig,fl;
		
		dig = alt /1000;
		fl = dig * 10;
		dig = alt % 1000;
		
		if (dig >= 250) fl += 5;
		if (dig >= 750) fl += 5;
			
		return (fl);
}

/* outputs the planes to the graphics */
outputplane(int secs, char *callsign, int x, int y, int alt, short knot, short deg)
{ 
 
		/*graphic output on plane*/
		al_clear();
		al_plane(g_x(x), g_y(y), callsign, Flightlevel(alt), knot, deg);
		al_clock(secs);
		al_refresh();
		sleep(1);

		/*numeric output on plane */
		fprintf(stderr,"%5ds %14s (%7d, %7d) (%3d, %3d) %5dft FL%3d %4dK H%3d \n",
		 secs, callsign, x, y, g_x(x), g_y(y), alt, Flightlevel(alt), knot, deg);

}

/* reads one plane at a time  */
flyoneplane(char *callsign,int x,int y,int alt,short knot,short  deg)
{

		int tcount=0;
 
		fprintf(stderr,"%5s  %14s (%7s, %7s) (%3s, %3s) %5s   FL%3s %4s  %3s \n", "ET", "Callsign", "X", "Y", "gx", "gy", "Alt", "", "Knots", "Deg");
		/*as long as the plane is over colorado */
		while(x >= 0 && x < MFX && y >= 0 && y < MFY)
		{
			outputplane(tcount*time,callsign,x,y,alt,knot,deg); 
			/*update x */
			x += dist(velX(fps(knot),deg),time);
			/*update y*/
			y += dist(velY(fps(knot), deg),time);
			/*update clock*/
			tcount++;
		}
		fprintf(stderr, "\n");
}

/* Gets the plane up and running to graphics */
mastersim()
{

		int x, y, alt, count, gx, gy;
		short h, air_speed, knot, deg;
		double vy, vx;
		char callsign[maxSign];
		/*scanf loop goes here*/
		while(count = (int)scanf("%s %d %d %d %hd %hd", callsign, &x, &y, &alt, &knot, &deg) == 6)
		{

		flyoneplane(callsign, x, y, alt, knot, deg);

		}
		/* print count scanf returned -1 or 0 */
		fprintf(stderr,"Failed to read: scanf returned %d\n",count);
}

/* opens grapics and runs the planes */
int main(void)
{

		if (al_initialize()!=0)
		{
			fprintf(stderr, "Drawable error are is (%d, %d) to (%d, %d)\n",
			al_min_X(), al_min_Y(), al_max_X(), al_max_Y());
			
			mastersim();

			al_teardown();
		}
		else
		{
			printf("There was an error that occured\n");
		}
}
