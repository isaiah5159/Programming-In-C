#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ssem.h"
#include "sshm.h"

/* 
    gcc –o ProcB ProcB.c ssem.o sshm.o
    ./ProcB.c
*/

/*Author: Isaiah Green */

typedef struct 
{ 
    int x;
    char y[5];
} slotA;
typedef struct 
{ 
    int x;
    char y[7];
} slotB;

int main()
{

    int out = 0, i; 
    int keyAF = 0x123900, keyBF = 0x123901, keyEA = 0x123902, keyEB = 0x123903, keySA = 0x123904, keySB = 0x123905, keyM = 0x123906, inital_value = 0; 
    int semAF, semBF, semEA, semEB, semM, shmidA, shmidB, n = 20, m = 30, mutex = 1;
    slotA *bufferA, tempA;
    slotB *bufferB, tempB;

    semAF = sem_create(keyAF, inital_value);
    if (semAF < 0) {printf ("error with sem_create\n"); exit(0);}

    semBF = sem_create(keyBF, inital_value);
    if (semBF < 0) {printf ("error with sem_create\n"); exit(0);} 

    semEA = sem_create(keyEA, n);
    if (semEA < 0) {printf ("error with sem_create\n"); exit(0);} 

    semEB = sem_create(keyEB, m);
    if (semEB < 0) {printf ("error with sem_create\n"); exit(0);} 

    semM = sem_create(keyM, mutex);
    if (semM < 0) {printf ("error with sem_create\n"); exit(0);}  
    
    shmidA = shm_get(keySA,(void**)&bufferA, 20*sizeof(slotA));
    if (shmidA < 0) {printf ("error with sem_get\n"); exit(0);}

    shmidB = shm_get(keySB,(void**)&bufferB, 30*sizeof(slotB));
    if (shmidB < 0) {printf ("error with sem_get\n"); exit(0);}

        for(i = 0; i < 500; i++)
        {
            sem_wait(semAF);
            
            tempA = bufferA[i % 20];

            sem_signal(semEA);
            
            /*start comsuming item1 and producing item2*/
                tempB.x = tempA.x * 10;
                sprintf(tempB.y,"%sOK", tempA.y);
            /*consuming item1 and producing item2 done*/

            sem_wait(semEB); 

            bufferB[i % 30] = tempB;


            sem_signal (semBF);
            

            if (i % 75 == 0)
            {
                usleep(300000);
            }
         }
}