#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ssem.h"
#include "sshm.h"

/* 
    gcc –o RF RF.c ssem.o sshm.o
    ./RF
*/

/*Author: Isaiah Green */

int main()
{
    int o, r, sem, key = 123900;
    char buffer[20];
    
    sem = sem_open(key);
    if (sem < 0) {printf ("error with sem_open\n"); exit(0);} 
    
    if (sem_wait(sem) < 0) {printf ("error with sem_wait\n"); exit(0);}

    o = open("data.txt", 0);
	if (o < 0) {printf("error with opening data.txt\n");return 0;} 
    r = read(o, buffer , 200);
	if (r < 0) {printf("error with reading in data.txt\n");return 0;}

    printf("What was read is: %s\n",buffer);

    if (sem_rm(sem) < 0) {printf ("error with sem_rm\n"); exit(0);}

}