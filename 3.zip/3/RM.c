#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ssem.h"
#include "sshm.h"

/* 
    gcc –o RM RM.c ssem.o sshm.o
    ./RM
*/

/*Author: Isaiah Green */
typedef struct 
{ 
    int x;
    double y[2];
} slot;

void main()
{
    int i=0, shmid, key = 123900;
    slot *buf; 

    shmid = shm_get(key,(void**)&buf, 5*sizeof(slot));
    if (shmid < 0) {printf ("error with sem_get\n"); exit(0);}

    while(i < 5)
    {
        printf("%d %lf %lf\n",buf[i].x, buf[i].y[0], buf[i].y[1]);
        
        i++;
    }

    if (shm_rm(shmid) < 0) {printf ("error with sem_rm\n"); exit(0);}
    
    exit(2);
}