#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ssem.h"
#include "sshm.h"

/* 
    gcc –o Proc4 Proc4.c ssem.o sshm.o
    ./Proc4
*/

/*Author: Isaiah Green */

int main()
{
    int key1 = 123900, key2 = 123901, key3 = 123902, key4 = 123903, keyA = 123904, keyM = 123905; 
    int *Account, shmid, semp1, semp2, semp3, semp4, semM, i, sum;

    semp1 = sem_open(key1);
    if (semp1 < 0) {printf ("error with sem_open\n"); exit(0);} 

    semp2 = sem_open(key2);
    if (semp2 < 0) {printf ("error with sem_open\n"); exit(0);} 

    semp3 = sem_open(key3);
    if (semp3 < 0) {printf ("error with sem_open\n"); exit(0);} 
    
    semp4 = sem_open(key4);
    if (semp4 < 0) {printf ("error with sem_open\n"); exit(0);}  

    semM = sem_open(keyM);
    if (semM < 0) {printf ("error with sem_open\n"); exit(0);}

    shmid = shm_get(keyA,(void**)&Account, 3*sizeof(int));
    if (shmid < 0) {printf ("error with sem_get\n"); exit(0);}

//synchronize with Proc1, Proc2 & Proc3 (4 process 4 way sync.)
    sem_signal(semp4);
    sem_signal(semp4);
    sem_signal(semp4);    
    sem_wait(semp1);
    sem_wait(semp2);
    sem_wait(semp3);

     for (i = 0; i < 5000; i++)
     {
        sem_wait(semM);
        sum = Account[0] + Account[1] + Account[2];
        if (sum != 30000)
        {
            printf("Proc4 when not 30000 %dth transaction\n", i);
        }
        if (i % 1000 == 0)
        {
            usleep(50000);
        }
        sem_signal(semM);
     }
     printf("Proc4 %dth transaction\n", i);
    sem_rm(semp1);
    sem_rm(semp2);
    sem_rm(semp3);
    sem_rm(semp4);
    sem_rm(semM);
    shm_rm(shmid);
}