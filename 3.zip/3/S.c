#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ssem.h"
#include "sshm.h"

/* 
    gcc –o S S.c ssem.o sshm.o
    ./S
*/

/*Author: Isaiah Green */

void main()
{
    int key = 123900, inital_value = 0, sem;
    
    sem = sem_create(key, inital_value);
    if (sem < 0) {printf ("error with sem_create\n"); exit(0);} 

    exit(1);
}