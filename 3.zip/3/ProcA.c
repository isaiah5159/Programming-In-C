#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ssem.h"
#include "sshm.h"

/* 
    gcc –o ProcA ProcA.c ssem.o sshm.o
    ./ProcA.c
*/

/*Author: Isaiah Green */

typedef struct 
{ 
    int x;
    char y[5];
} slotA;

typedef struct 
{ 
    int x;
    char y[7];
} slotB;

int main()
{
    int in = 0, i; 
    int keyAF = 0x123900, keyBF = 0x123901, keyEA = 0x123902, keyEB = 0x123903, keySA = 0x123904, keySB = 0x123905, keyM = 0x123906; 
    int semAF, semBF, semEA, semEB, semM, shmidA, shmidB, holder;
    slotA *bufferA;
    slotA tempA;
    slotB *bufferB;
    slotB tempB;

    semAF = sem_open(keyAF);
    if (semAF < 0) {printf ("error with sem_open\n"); exit(0);} 

    semBF = sem_open(keyBF);
    if (semBF < 0) {printf ("error with sem_open\n"); exit(0);} 

    semEA = sem_open(keyEA);
    if (semEA < 0) {printf ("error with sem_open\n"); exit(0);} 

    semEB = sem_open(keyEB);
    if (semEB < 0) {printf ("error with sem_open\n"); exit(0);}

    semM = sem_open(keyM);
    if (semM < 0) {printf ("error with sem_open\n"); exit(0);}  
    
    shmidA = shm_get(keySA,(void**)&bufferA, 20*sizeof(slotA));
    if (shmidA < 0) {printf ("error with sem_get\n"); exit(0);}

    shmidB = shm_get(keySB,(void**)&bufferB, 30*sizeof(slotB));
    if (shmidB < 0) {printf ("error with sem_get\n"); exit(0);}

        /*start produce*/
        for(i = 0; i < 500; i++)
        {
            sem_wait(semEA);

            if (i % 2 == 0)
            {
                sprintf(bufferA[i % 20].y,"Best1");
            }
            else
            {
                sprintf(bufferA[i % 20].y,"Hello");
            }        
            /* an itemA produced*/
            bufferA[i % 20].x = i + 1;
            
            sem_signal(semAF);

            if (i % 100 == 0)
            {
                usleep(300000);
            }
        } 

    sem_rm(semAF);
    sem_rm(semBF);
    sem_rm(semEA);
    sem_rm(semEB);
    shm_rm(shmidA);
    shm_rm(shmidB);
}