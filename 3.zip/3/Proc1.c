#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ssem.h"
#include "sshm.h"

/* 
    gcc –o Proc1 Proc1.c ssem.o sshm.o
    ./Proc1
*/

/*Author: Isaiah Green */

int main()
{
    int i, internal_reg;

/* create and initialize all necessary semaphores */
    int key1 = 123900, key2 = 123901, key3 = 123902, key4 = 123903, keyA = 123904, keyM = 123905, inital_value = 0; 
    int *Account, shmid, semp1, semp2, semp3, semp4, semM, mutex = 1;

    semp1 = sem_create(key1, inital_value);
    if (semp1 < 0) {printf ("error with sem_create\n"); exit(0);} 

    semp2 = sem_create(key2, inital_value);
    if (semp2 < 0) {printf ("error with sem_create\n"); exit(0);} 

    semp3 = sem_create(key3, inital_value);
    if (semp3 < 0) {printf ("error with sem_create\n"); exit(0);} 
    
    semp4 = sem_create(key4, inital_value);
    if (semp4 < 0) {printf ("error with sem_create\n"); exit(0);} 

    semM = sem_create(keyM, mutex);
    if (semM < 0) {printf ("error with sem_create\n"); exit(0);}  

/* created shared memory array of 3 integers Account*/
    shmid = shm_get(keyA,(void**)&Account, 3*sizeof(int));
    if (shmid < 0) {printf ("error with sem_get\n"); exit(0);}

    Account[0]=10000;

    Account[1]=10000;

    Account[2]=10000;

/* synchronize with Proc2, Proc3 and Proc4 (4 process 4 way synch.)*/
    sem_signal(semp1);
    sem_signal(semp1);
    sem_signal(semp1);    
    sem_wait(semp2);
    sem_wait(semp3);
    sem_wait(semp4);

    for(i = 0; i < 2000; i++)
    {
        sem_wait(semM);

        internal_reg = Account[0];

        internal_reg = internal_reg - 200;

        Account[0] = internal_reg;

        /* same thing, except we're adding $200 to account1 now... */

        internal_reg = Account[1];

        internal_reg = internal_reg + 200;

        Account[1] = internal_reg;
        
        if(i % 100 == 0)
        {
            printf("Proc1 %dth transaction\n", i);
            printf("Money in account0 is :%d\n", Account[0]);
            printf("Money in account1 is :%d\n", Account[1]);
            printf("Money in account2 is :%d\n", Account[2]);
            printf("Proc1 sum is: %d\n", Account[0] + Account[1] + Account[2]);
        }
        if (i % 600 == 0)
        {
            usleep(200000);
        } 
        sem_signal(semM);
    }

    /* Add a code that prints contents of each account and

   their sum after 100th, 200th, 300th, .... and 1900th

   iteration*/
  }

/*in the code above include some wait and signal operations on semaphores. Do not over-synchronize. */
