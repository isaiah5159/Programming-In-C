#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ssem.h"
#include "sshm.h"

/* 
    gcc –o Proc3 Proc3.c ssem.o sshm.o
    ./Proc3
*/

/*Author: Isaiah Green */
int main()
{
    int i, internal_reg;
    int key1 = 123900, key2 = 123901, key3 = 123902, key4 = 123903, keyA = 123904, keyM = 123905; 
    int *Account, shmid, semp1, semp2, semp3, semp4, semM;

    semp1 = sem_open(key1);
    if (semp1 < 0) {printf ("error with sem_open\n"); exit(0);} 

    semp2 = sem_open(key2);
    if (semp2 < 0) {printf ("error with sem_open\n"); exit(0);} 

    semp3 = sem_open(key3);
    if (semp3 < 0) {printf ("error with sem_open\n"); exit(0);} 
    
    semp4 = sem_open(key4);
    if (semp4 < 0) {printf ("error with sem_open\n"); exit(0);}

    semM = sem_open(keyM);
    if (semM < 0) {printf ("error with sem_open\n"); exit(0);}  

    shmid = shm_get(keyA,(void**)&Account, 3*sizeof(int));
    if (shmid < 0) {printf ("error with sem_get\n"); exit(0);}

//synchronize with Proc1, Proc2 & Proc4 (4 process 4 way sync.)
    sem_signal(semp3);
    sem_signal(semp3);
    sem_signal(semp3);    
    sem_wait(semp1);
    sem_wait(semp2);
    sem_wait(semp4);

     for (i = 0; i < 2000; i++)

        {
          sem_wait(semM);

          internal_reg = Account [2];

          /*Proc3 takes from  Account[2]*/

          internal_reg = internal_reg - 200;

          Account[2] = internal_reg;

          /*Proc3 adds into Account[0]*/

          internal_reg = Account [0];

          internal_reg = internal_reg + 200;

          Account[0] = internal_reg;

            if(i % 100 == 0)
            {
                printf("Proc3 %dth transaction\n", i);
                printf("Money in account0 is :%d\n", Account[0]);
                printf("Money in account1 is :%d\n", Account[1]);
                printf("Money in account2 is :%d\n", Account[2]);
                printf("Proc3 sum is: %d\n", Account[0] + Account[1] + Account[2]);
            }
            if (i % 500 == 0)
            {
                usleep(300000);
            }
            sem_signal(semM);
         }

  /* Add a code that prints contents of each account

    and their sum after 100th, 200th, 300th, .... and 1900th

    iteration*/

}

/*in the code above include some wait and signal operations on semaphores. Do not over-synchronize. */