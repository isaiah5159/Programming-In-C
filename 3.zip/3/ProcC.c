#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ssem.h"
#include "sshm.h"

/* 
    gcc –o ProcC ProcC.c ssem.o sshm.o
    ./ProcC.c
*/

/*Author: Isaiah Green */

typedef struct 
{ 
    int x;
    char y[7];
} slotB;

int main()
{
    int outB = 0, i; 
    int keyBF = 0x123901, keyEB = 0x123903, keySB = 0x123905, keyM = 0x123906; 
    int semBF, semEB, semM, shmidB;
    slotB *bufferB;
    slotB tempB;

    semBF = sem_open(keyBF);
    if (semBF < 0) {printf ("error with sem_open\n"); exit(0);} 

    semEB = sem_open(keyEB);
    if (semEB < 0) {printf ("error with sem_open\n"); exit(0);} 

    semM = sem_open(keyM);
    if (semM < 0) {printf ("error with sem_open\n"); exit(0);} 

    shmidB = shm_get(keySB,(void**)&bufferB, 30*sizeof(slotB));
    if (shmidB < 0) {printf ("error with sem_get\n"); exit(0);}

        for(i = 0; i < 500; i++)
        {
            sem_wait(semBF);
            
            /*start consuming itemB*/
            
            printf("%d%s \n",bufferB[i % 30].x, bufferB[i % 30].y); 

            sem_signal(semEB);
            /*consuming itemB done*/
            if (i % 100 == 0)
            {
                usleep(300000);
            }
        }
        
}