#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ssem.h"
#include "sshm.h"

/* 
    gcc –o WF WF.c ssem.o sshm.o
    ./WF
*/

/*Author: Isaiah Green */

int main()
{
    int c, w, sem, key = 123900;
    char buffer[20];

    sem = sem_open(key);
    if (sem < 0) {printf ("error with sem_open\n"); exit(0);} 

    c = creat("data.txt", 448);
	if (c < 0) {printf("error with creating data\n");return 0;}

    printf("Please enter content up to 20 characters: ");

    scanf("%20s", &buffer);

    w = write(c, buffer, 20);
    if (w < 0) {printf ("error with writing in data \n");return 0;}

    if (sem_signal(sem) < 0) {printf ("error with sem_signal\n"); exit(0);}
    
    exit(3);
}
