#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "ssem.h"
#include "sshm.h"

/* 
    gcc –o WM WM.c ssem.o sshm.o
    ./WM
*/

/*Author: Isaiah Green */
typedef struct 
{ 
    int x;
    double y[2];
} slot;

void main()
{
    int i=0, key = 123900, shmid;
    slot buffer;
    slot *buf;

    shmid = shm_get(key,(void**)&buf, 5*sizeof(slot));
    if (shmid < 0) {printf ("error with sem_get\n"); exit(0);}

    while (i < 5)
    {
        printf("Please enter 3 numbers: ");
        scanf("%d %lf %lf", &buffer.x, &buffer.y[0], &buffer.y[1]);
        buf[i] = buffer;

        i++;
    }
    exit(0);
}