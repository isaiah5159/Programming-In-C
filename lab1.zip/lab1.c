#include<stdio.h>

/*Author: Isaiah Green */

int main(void)
{
	char string1[]="The quick fox jumped over the brown dog.";
	int i;
	int max=1;
	
	for(i=0;i<max;i++)
	{
		printf("Hello, World!\n");	
	}
	printf("The sample sentence is \"%s\".\n",string1);
	return(0);
}

