#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/time.h>

/* 
    gcc -o PipeRW1 PipeRW1.c
    ./PipeRW1
*/

/*Author: Isaiah Green */
int main(int argc, char *argv[])
{
    /*Declared variables*/
    int i, w1, readfd, writefd;
    char a[] = "aaa", temp[7];
    sscanf(argv[0], "%d", &readfd);
    sscanf(argv[1], "%d", &writefd);

        for (i = 001; i <= 500; i++)
        {
            sprintf(temp , "%03daaa", i);
            // check statment printf("[%s]\n", temp);
            
            // Close reading end of pipe
            close(readfd); 

            // Write input string and close writing end of pipe.
            w1 = write(writefd, temp, 6);
            if (w1 < 0) {printf ("error with writing in pipe\n");return 0;}
            if(i % 100 == 0)
            {
                usleep(100000);
            }
        }
        exit(0);
}