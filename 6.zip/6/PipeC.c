#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

/* 
    gcc -o PipeC PipeC.c
    ./PipeC
*/

/*Author: Isaiah Green */

/*Process A*/
void main()
{
    /*Declared variables*/
    int B, C, D, P;
    char readd[11], writed[11];

    // Used to store two ends of first pipe
    int fd[2]; 

    P = pipe(fd);
    if (P < 0){printf("Pipe Failed"); exit(0);}

    sprintf(readd, "%d", fd[0]);
    sprintf(writed, "%d", fd[1]);

        /*Process B*/
        B = fork();
        if (B < 0) {printf ("error with fork\n"); exit(0);} 
        if (B == 0)
        {
            execlp("PipeW1",readd, writed);
            printf("exit failed\n");
            exit(0);   
        }

        /*Process C*/
        C = fork();
        if (C < 0) {printf ("error with fork\n"); exit(0);} 
        if (C == 0)
        {
            execlp("PipeW2",readd, writed);
            printf("exit failed\n");
            exit(0);   
        }

        /*Process D*/
        D = fork();
        if (D < 0) {printf ("error with fork\n"); exit(0);} 
        if (D == 0)
        {
            execlp("PipeR",readd, writed);
            printf("exit failed\n");
            exit(0);   
        }
        exit(1);       
}