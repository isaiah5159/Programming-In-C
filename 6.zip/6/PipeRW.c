#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

/* 
    gcc -o PipeRW PipeRW.c
    ./PipeRW
*/

/*Author: Isaiah Green */

int main()
{
    /*Declared variables*/
    int B, C, P, i, w1, w2, count = 0, hold = 0, r = 0, x = 0, cr = 0;
    char letters[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ",  a[] = "aaa", temp[7], buffer[100];
    
    // Used to store two ends of first pipe
    int fd[2]; 

    P = pipe(fd);
    if (P < 0){printf("Pipe Failed"); return 1;}

    /*Process B*/
    B = fork();
    if (B < 0) {printf ("error with fork\n"); exit(0);} 

    else if (B == 0)
    {   
        for (i = 001; i <= 500; i++)
        {
            sprintf(temp , "%03daaa", i);
            // check statment printf("[%s]\n", temp);
            
            // Close reading end of pipe
            close(fd[0]); 

            // Write input string and close writing end of pipe.
            w1 = write(fd[1], temp, 6);
            if (w1 < 0) {printf ("error with writing in pipe\n");return 0;}
            if(i % 100 == 0)
            {
                usleep(100000);
            }
        }
        exit(0);
    }

    /*Process C*/
    C = fork();
    if (C < 0) {printf ("error with fork\n"); exit(0);} 
   
    else if (C == 0)
    {   
        for (i = 0; i < 260; i++)
        {
            if (count == 26)
            {
                count = 0;
                hold = hold + 1;
            }

            if (hold == 10)
            {
                hold = 0;
            }
            sprintf(temp, "%cx%d",letters[count], hold);

            // this is for testing purposes printf("[%s] ",temp2);
            count = count + 1;

            // Close reading end of pipe
            close(fd[0]); 

            w2 = write(fd[1], temp, 3);
            if (w2 < 0) {printf ("error with writing in pipe\n");return 0;}
            if(i % 60 == 0)
            {
                usleep(300000);
            }
        }
        exit(1);
    }
    close(fd[1]); 
    while((r = read(fd[0], buffer, 100)) > 0)
    {
        printf ("%.*s\n",r,buffer);
        if(x % 50 == 0)
        {
            usleep(200000);
        }
        x++;
        cr += r;
    }
    printf("\nThe number of issues read %d Number of characters read %d\n",x,cr);
    exit(2);
}