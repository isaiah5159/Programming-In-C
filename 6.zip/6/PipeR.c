#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

/* 
    gcc -o PipeR PipeR.c
    ./PipeR
*/

/*Author: Isaiah Green */
int main (int argc, char *argv[])
{
    /*Declared variables*/
    int P, r = 0, x = 0, cr = 0, readfd, writefd;
    char buffer[100];
    sscanf(argv[0], "%d", &readfd);
    sscanf(argv[1], "%d", &writefd);


    close(writefd); 
    while((r = read(readfd, buffer, 100)) > 0)
    {
        printf ("%.*s\n",r,buffer);
        if(x % 50 == 0)
        {
            usleep(200000);
        }
        x++;
        cr += r;
    }
    printf("\nThe number of issues read %d Number of characters read %d\n",x,cr);
    exit(2);
}