#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/time.h>

/* 
    gcc -o PipeRW2 PipeRW2.c
    ./PipeRW2
*/

/*Author: Isaiah Green */
int main (int argc, char *argv[])
{
    /*Declared variables*/
    int P, i, w2, count = 0, hold = 0, r = 0, readfd, writefd;
    char letters[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ", temp[7];

    sscanf(argv[0], "%d", &readfd);
    sscanf(argv[1], "%d", &writefd);

            for (i = 0; i < 260; i++)
        {
            if (count == 26)
            {
                count = 0;
                hold = hold + 1;
            }

            if (hold == 10)
            {
                hold = 0;
            }

            sprintf(temp, "%cx%d",letters[count], hold);

            // this is for testing purposes printf("[%s] ",temp2);
            count = count + 1;

            // Close reading end of pipe
            close(readfd); 

            w2 = write(writefd, temp, 3);
            if (w2 < 0) {printf ("error with writing in pipe\n");return 0;}
            if(i % 60 == 0)
            {
                usleep(300000);
            }
        }
        exit(1);
}