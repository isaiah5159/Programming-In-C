#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/time.h>

/*
    gcc lab5.c -o lab5 -lpthread -lrt 
    ./lab5
*/

/*Author: Isaiah Green */

#define N 6000
#define M 3000
#define P 1000

long int A[N][M];
long int B[M][P];
long int C[N][P];
long int C1[N][P];

int n, m, p, thread;

void matrixA()
{
  int i, j;

  for (i = 0; i < n; i++)
  {
    for (j = 0; j < m; j++)
    {
      A[i][j] = i * j;
    }
  }
}

void matrixB()
{
  int i, j;

  for (i = 0; i < m; i++)
  {
    for (j = 0; j < p; j++)
    {
      B[i][j] = i + j;
    }
  }
}

void matrixC()
{
  int i, j, k;

  for (i = 0; i < n; i++)
  {
    for (j = 0; j < p; j++)
    {
      C[i][j] = 0;
      for (k = 0; k < m; k++)
      {
        C[i][j] += A[i][k] * B[k][j];
      }
    }
  }
}

void *multiplymatrices(void *num)
{

  int threadn = *(int *)num;
  int i, j, k, srow, erow;

  srow = threadn * (n / thread);
  if (threadn + 1 == thread)
    erow = n;
  else
    erow = (threadn + 1) * (n / thread);

  for (i = srow; i < erow; i++)
  {
    for (j = 0; j < p; j++)
    {
      C1[i][j] = 0;
      for (k = 0; k < m; k++)
      {
        C1[i][j] += A[i][k] * B[k][j];
      }
    }
  }
  free(num);
  pthread_exit(NULL);
}

int matrixequality()
{
  int i, j;

  for (i = 0; i < n; i++)
  {
    for (j = 0; j < p; j++)
    {
      if (C[i][j] != C1[i][j])
      {
        printf("%d\t%d\t%d\n", i, j, C[i][j]);
        return 0;
      }
    }
  }
  return 1;
}

int main()
{

  int i, j, k, equality, maxt = 6;
  double time;
  struct timeval stime, etime;

  /*Header*/
  printf("Enter n (<=6000), m (<=3000), p (<=1000): ");
  scanf("%d %d %d", &n, &m, &p);
  printf("\nn = %d, m = %d, p = %d", n, m, p);
  printf("\nThreads\tSeconds\n");

  matrixA();
  matrixB();
  gettimeofday(&stime, NULL);
  matrixC();
  gettimeofday(&etime, NULL);
  time = (etime.tv_sec - stime.tv_sec) + ((etime.tv_usec - stime.tv_usec) / 1000000.0);
  printf("1\t%.2f\n", time);

  for (i = 1; i < maxt; i++)
  {
    thread = i + 1;
    pthread_t tid[thread];
    gettimeofday(&stime, NULL);
    for (j = 0; j < thread; j++)
    {
      int *tnum = malloc(sizeof(int));
      *tnum = j;
      pthread_create(&tid[j], NULL, multiplymatrices, (void *)tnum);
    }
    for (k = 0; k < thread; k++)
      pthread_join(tid[k], NULL);

    gettimeofday(&etime, NULL);
    time = (etime.tv_sec - stime.tv_sec) + ((etime.tv_usec - stime.tv_usec) / 1000000.0);
    printf("%d\t%.2f\n", i + 1, time);
    equality = matrixequality();
    if (equality == 1)
    {
      printf("Comparison: No error\n");
    }
    else
    {
      printf("Something's gone wrong\n");
    }
  }
}
