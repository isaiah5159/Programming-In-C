#include <stdio.h>
#include "structs.h"
#include "structs2.h"
#include "linkedlist.h"

/* Author: Isaiah Green */

#define MFX (380*5280)/* x boundary for graphics */
#define MFY (280*5280)/* y boundary for graphics */

/*test that i can do an action function for lab3 */
void printplane(void *data)
{
		oneplane *jet = data;
	printf("%s %0.0lf %0.0lf %0.0lf %hd %hd %d \n", jet->callsign, jet->x, jet->y, jet->alt, jet->knot, jet->deg, jet->pilot);
}

/*test that i can do an comparision function for lab3 */
int westmost( void *data1, void *data2)
{
	oneplane *jet = data1;
	oneplane *jet2 = data2;
	
	printf("%s %0.0lf \n", jet->callsign, jet->x);
		
	printf("%s %0.0lf \n", jet2->callsign, jet2->x);
	
	if( jet -> x <= jet2 -> x) 
	{
		printf("%s is west of %s \n",jet->callsign,jet2->callsign);
		return(1);
	}
	else
	{
		printf("%s is NOT west of %s \n",jet->callsign,jet2->callsign);
		return(0);
	}
}

/*test that i can do an comparision function for lab3 */
int higher( void *data1, void *data2)
{
	oneplane *jet = data1;
	oneplane *jet2 = data2;
	
	printf("%s %0.0lf \n", jet->callsign, jet->alt);
		
	printf("%s %0.0lf \n", jet2->callsign, jet2->alt);

	if( jet -> alt >= jet2 -> alt) 
	{
		printf("%s is high of %s \n",jet->callsign,jet2->callsign);
		return(1);
	}
	else
	{
		printf("%s is NOT high of %s \n",jet->callsign,jet2->callsign);
		return(0);
	}
}

/*test that i can do an criteria function for lab3 */
int outside_colorado(void *data)
{
		/*as long as the plane is over colorado */
		oneplane *jet = data;
		if (jet -> x >= 0 && jet -> x < MFX && jet -> y >= 0 && jet -> y < MFY)
		{
			printf("%s is in colorado \n",jet->callsign);
			return(0);
		}
		else
		{
			printf("%s is not in colorado \n",jet->callsign);		
			return(1);
		}		
}

int main(void)
{
		oneplane k ={"k", 7, 7, 30000, 0, 0, 1986, 320};
		oneplane t = {"t", 8, 8, 40000, 0, 1, 1986, 320};
		oneplane p = {"p", 9, 9, 20000, 0, 2, 1986, 320};
		
		printplane(&k);
		westmost(&k,&t);
		higher(&k,&t);
		outside_colorado(&k);
	
}		

