/* Author: Isaiah Green */

#define maxSign 15 /* max callsign you need*/
/*simulation structure in here */
typedef struct 
{
	int elapsedtime;
	void *storagepointer;
	
}sim;

typedef struct
{
		char callsign[maxSign];
		double x, y, alt;
		int   roc, pilot;
		short knot, deg;
}oneplane;

