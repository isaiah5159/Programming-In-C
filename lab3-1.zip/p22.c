#include <stdio.h>
#include <string.h>
/* Author: Isaiah Green */

#include "structs.h"
void sl(oneplane *p)
{
		printf("sl on %s \n",p->callsign);
}

int main(void)
{
		/*add more to this list later*/
		void (*fp[])(oneplane *p)={sl};
		/*the next two lines will not be in production code*/
		oneplane p = {"TwoTwoFive",1,1,1800},*pp=&p;
		p.pilot=0;
		/*use the pilot to make the call*/
		fp[pp->pilot](pp);
}

