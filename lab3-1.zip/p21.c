#include <stdio.h>
#include <stdlib.h>

/* Author: Isaiah Green */
#include "structs.h"

oneplane *allocateplane()
{
	void *ct;
	static int count = 0;
	
	ct = calloc(1, sizeof(oneplane));
	
	if (ct != NULL)
	{
		/*printf("The pointer from calloc is: %d \n", ct);*/
		count ++;
		printf("DIAGNOSTIC: allocate_plane: %d planes allocated.\n",count);
		
	}
	else
	{
		printf("ERROR: Failed to allocate plane");
	}
	return(ct);
}

void freePlane(oneplane *jet)
{
	static int count = 0;
	free(jet);
	count ++;
	fprintf(stderr,"DIAGNOSTIC: recycle_plane: %d planes recycled.\n",count);
}

int main(void)
{
		oneplane *ct, *m;
	
		ct = allocateplane();
		
		freePlane(ct);		
}
