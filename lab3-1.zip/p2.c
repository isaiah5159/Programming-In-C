#include <stdio.h>

/* Author: Isaiah Green */

int main(void)
{
		char callsign[]="TwoTwoFive";
		int x=1000000, y=1000000, alt=35400, time=0, gx=50, 			gy=7, knot=1396, deg=225,fl=355;
		int t=600,z=360,a=360,g=22,gp=21,knots=988;

fprintf(stderr,"%5s %15s (%7s, %7s) (%3s, %3s) %7s FL%s %3s  %3s \n", "ET", "Callsign", "X", "Y", "gx", "gy", "Alt", "", "Knots", "Deg");

fprintf(stderr,"%5ds %14s (%7d, %7d) (%3d, %3d) %5dft FL%3d %3dK H%3d \n", time, callsign, x, y, gx, gy, alt, fl, knot, deg);


fprintf(stderr,"%5ds %14s (%7d, %7d) (%3d, %3d) %5dft FL%3d %3dK H%3d \n", t, callsign, z, a, g, gp, alt, fl, knots, deg);

/*numeric output on plane */
		fprintf(stderr,"%5ds %14s (%7d, %7d) (%3d, %3d) %5dft FL%3d %4dK H%3d \n",
		 secs, callsign, x, y, g_x(x), g_y(y), alt, Flightlevel(alt), knot, deg);

}
