/* Author: Isaiah Green */

#define maxSign 15 /* max callsign you need*/

/*testing prototype 24 */
typedef struct
{
		char callsign2[maxSign];
		double x2, y2, alt2;
		int   roc2, pilot2;
		short knot2, deg2;
}oneplane2;
