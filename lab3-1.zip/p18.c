#include <stdio.h>
#include <stdlib.h>

/* Author: Isaiah Green */

#include "structs.h"

int main(void)
{
int *ct, *m;
	
	ct = calloc(1,sizeof(oneplane));
	if (ct != NULL)
	{
		printf("The size of calloc is: %d \n", ct);
	}
	

}
