#include <stdio.h>
#include <stdlib.h>

/* Author: Isaiah Green */
#include "structs.h"
/* allocateplane goes here for p21*/
void freePlane(oneplane *jet)
{
	static int count = 0;
	free(jet);
	count ++;
	fprintf(stderr,"recycle_plane: %d planes recycled.\n",count);
}

int main(void)
{
		oneplane *ct, *m;
	
		ct = calloc(1,sizeof(oneplane));
		freePlane(ct);		
}
