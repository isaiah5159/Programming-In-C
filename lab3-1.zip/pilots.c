#include <stdio.h>
#include <string.h>
#include "structs.h"

/* Author: Isaiah Green */

short heading(short deg)
{
		if(deg < 0)
		{
			deg += 360;
		}
		if(deg >= 360)
		{
			deg -= 360;
		}   
		return(deg);

}

void sl(oneplane *k)
{
		
		k->roc = 0;
		/* where you say callsign there will be a number for it*/
		fprintf(stderr,"DIAGNOSTIC: %s is flying straight and level. \n", k ->callsign);

}

void dl(oneplane *k)
{ 
		
		if(k->alt > 20500)
		{
			k->deg = heading(k->deg - 15);
			fprintf(stderr,"DIAGNOSTIC: Descendleft is turning left ");
		}
		else
		{
			fprintf(stderr,"DIAGNOSTIC: Descendleft is flying straight ");
		}
		if(k->alt > 19500)
		{
			k->roc = -400;
			fprintf(stderr,"and descending. \n");
		}
		else
		{
			k->roc = 0;
			fprintf(stderr,"and leveled off. \n");
		}
		
}
void cr(oneplane *k)
{
		if(k->alt < 30500)
		{
			k->deg = heading(k->deg + 15);
			fprintf(stderr,"DIAGNOSTIC: ClimbRight is turning right ");
		}
		else
		{
			fprintf(stderr,"DIAGNOSTIC: ClimbRight is flying straight ");
		}
		if(k->alt < 33500)
		{
			k->roc = 400;
			fprintf(stderr,"and climbing. \n");
		}
		else
		{
			k->roc = 0;
			fprintf(stderr,"and leveled off. \n");
		}
}

void pilotinput(void *data)
{
		oneplane *k = data;
		
		void (*fp[])(oneplane *k)={sl,dl,cr};

		fp[k->pilot](k);	
}

