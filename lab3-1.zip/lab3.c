#include <stdio.h>
#include <math.h>
#include "libatc.h"
#include "structs.h"

/* Author: Isaiah Green */

#define KNOTS2FPS 1.687809855643 /* knot feet per second */
#define M_PI 3.14159265359070323846 /* pi */
#define MAXSIGN 15 /* max callsign you need */
#define TIME 60 /* delta time change to all caps and make all define all caps future note*/
#define MFX (380*5280)/* x boundary for graphics */
#define MFY (280*5280)/* y boundary for graphics */

/*lab3 2>errs < 4jets.input*/

/* The two functions help with memory for the linklist*/
oneplane *allocateplane();
void freePlane(oneplane *jet);

/* This function helps with the steering of the plane */
void pilotinput(void *data);

/*These functions help with the comparison for the linklist*/
int outside_colorado(void *data);
int westmost(void *data1, void *data2);
int higher(void *data1, void *data2);

/* calculates degrees to radians */
double Radians(short heading)
{

		return(heading * M_PI/180.0);
}

/* calulates the fps/speed */
double fps(short speed)
{

		return(KNOTS2FPS *speed);	
}

/* calulates the velocity of y direction */
double velY(double speed,short head)
{
		double velocity;
		
		velocity = speed *cos(Radians(head));
		
		return(velocity);
}

/* calulates the velocity of x direction */
double velX(double speed,short head)
{
		double vel;
		
		vel = speed *sin(Radians(head));
		
		return(vel);
}

/* calculates the distance for x and y direction*/
double dist(double ve, int t)
{
		double dz;
		
		dz = ve * t;
		
		return(dz);
}

/* calculates the gx for \graphics */
int g_x(double xdis)
{
		int gx,c,offX;
		
		c = 1 + (al_max_X()  - al_min_X() );
		offX = xdis*c/MFX;
		gx = al_min_X()  + offX;
		
		/*printf("gx = %d\n",gx);*/
		return(gx);
}

/* calulates the gy for graphics */
int g_y(double ydis)
{
		int gy,r,offY;
		
		r = 1 + (al_max_Y() - al_min_Y());
		offY = ydis*r/MFY;
		gy = al_max_Y() - offY;
		
		/*printf("gy = %d\n",gy);*/
		return(gy);
}

/* calulates the altitude/flight level */
int Flightlevel(int alt)
{
		int dig,fl;
		
		dig = alt /1000;
		fl = dig * 10;
		dig = alt % 1000;
		
		if (dig >= 250) fl += 5;
		if (dig >= 750) fl += 5;
			
		return (fl);
}
/* Draws one plane for graphics */
void drawplane(void *data)
{
		oneplane *jet = data;
 		al_plane(g_x(jet -> x), g_y(jet -> y), jet -> callsign, Flightlevel(jet -> alt), jet -> knot, jet -> deg);
}

/* Updates x,y, and altitude */
void moveplane(void *data)
{
		oneplane *jet = data;
		/* update x */
		jet -> x += dist(velX(fps(jet->knot),jet->deg),TIME);
		/* update y */
		jet -> y += dist(velY(fps(jet->knot), jet->deg),TIME);
		/*update alt */
		jet -> alt += jet -> roc;
}

/* Printing the table */
void printplane(void *data)
{
		oneplane *jet = data;
		/*numeric output on plane */
		fprintf(stderr,"%14s (%7.0lf, %7.0lf) (%3d, %3d) %5.0lfft FL%3d %4hdK H%3hd \n",
		  jet -> callsign, jet -> x, jet -> y, g_x(jet -> x), g_y(jet -> y), jet -> alt, Flightlevel(jet -> alt), jet -> knot, jet -> deg);
}

/* Printing the header */
printplanes(sim *s)
{	
		sort(s -> storagepointer, westmost);
		fprintf(stderr,"Elapsed time:%5d seconds.\n",s -> elapsedtime);
		fprintf(stderr,"%14s (%7s, %7s) (%3s, %3s) %5s   FL%3s %4s  %3s \n", "Callsign", "X", "Y", "gx", "gy", "Alt", "", "Knots", "Deg");
		iterate(s -> storagepointer, printplane);
		fprintf(stderr, "\n");
}

/* Shipping the planes to graphics */
drawplanes(sim *s)
{		
		oneplane k;
		/* graphic output on plane */
		sort(s -> storagepointer, higher);
		al_clear();
		iterate(s -> storagepointer, drawplane);
		al_clock(s -> elapsedtime);
		al_refresh();
		sleep(1);
}

/* Telling you about the planes */
outputplanes(sim *s)
{ 	
		drawplanes(s);
		printplanes(s);
}

/* As long as the list has planes keep flying */
flyplanes(sim *s)
{
		/*as long as the plane is over colorado */
		while(s -> storagepointer != NULL)
		{
			outputplanes(s); 
			/*iterate with pilot steering*/
			iterate(s -> storagepointer, pilotinput);
			/*iterate with move plane*/
			iterate(s -> storagepointer, moveplane);
			/*deletesome to free planes outside of colorado*/
			deleteSome(&s -> storagepointer, outside_colorado,freePlane);  
			s -> elapsedtime += TIME;
		}
		
		fprintf(stderr, "\n");
		fprintf(stderr, "DIAGNOSTIC: ClimbRight leaves the simulation.\n");
		fprintf(stderr, "DIAGNOSTIC: Descendleft leaves the simulation.\n");
}

/* Add one plane at a time to memory */
void addplane(sim *s,oneplane *jet)
{
		oneplane *dynamic = allocateplane();
		if (dynamic != NULL)
		{
			*dynamic = *jet;	
			if(!insert(&s -> storagepointer, dynamic, higher))
			{
				freePlane(dynamic);
			}	
		}
}

/* Reads in all planes to put into sim */
readplanes(sim *s)
{
		int count = 0;
		
		oneplane k;
		
		/*scanf loop goes here*/
		while(count = (int)scanf("%s %lf %lf %lf %hd %hd %d", k.callsign, &k.x, &k.y, &k.alt, &k.knot, &k.deg, &k.pilot) == 7)
		{
			addplane(s, &k);
		}
		/* print count scanf returned -1 or 0 */
		fprintf(stderr,"Failed to read: scanf returned %d\n",count);
		
}

/* Attempting to read and fly planes */
void attemptsim()
{
		sim colorado = {0, NULL};
		readplanes(&colorado);
		flyplanes(&colorado);
}

/* opens grapics and attempts to get planes up and running */
int main(void)
{
		if (al_initialize()!=0)
		{
			fprintf(stderr, "Drawable area is (%d, %d) to (%d, %d)\n",
			al_min_X(), al_min_Y(), al_max_X(), al_max_Y());
			
			attemptsim();
			
			al_teardown();
		
		}
		else
		{
			printf("There was an error that occured\n");
		}
}

