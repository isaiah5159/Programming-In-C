#include <stdio.h>

/* Author: Isaiah Green */

#include "structs.h"
/*test that i can do an action function for lab3 */
void printplane(void *data)
{
		oneplane *jet = data;
	printf("%s %0.0lf %0.0lf %0.0lf %hd %hd %d \n", jet->callsign, jet->x, jet->y, jet->alt, jet->knot, jet->deg, jet->pilot);
}

int main(void)
{
		oneplane k;
		int count = 0;
		
		while(count = (int)scanf("%s %lf %lf %lf %hd %hd %d", k.callsign, &k.x, &k.y, &k.alt, &k.knot, &k.deg, &k.pilot) == 7)
{
		printf("%s %0.0lf %0.0lf %0.0lf %hd %hd %d \n", k.callsign, k.x, k.y, k.alt, k.knot, k.deg, k.pilot);
		
		printplane(&k);
}

}

