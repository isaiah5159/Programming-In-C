#include <stdio.h>
#include <stdlib.h>

/* Author: Isaiah Green */

#include "structs.h"

int main(void)
{
oneplane *ct, *m;
	
	ct = calloc(1,sizeof(oneplane));
	printf("The pointer from calloc is: %p \n", ct);
	
	
	m = malloc(sizeof(oneplane));
	printf("The pointer from  malloc is: %p \n", m);
	free(m);
	free(ct);
}
