#include <stdio.h>
#include <string.h>
/* Author: Isaiah Green */

#include "structs.h"

short heading(short deg)
{
		if(deg < 0)
		{
			deg += 360;
		}
		if(deg >= 360)
		{
			deg -= 360;
		}   
		return(deg);

}

void sl()
{
		oneplane k;
		k.roc = 0;
		/* where you say callsign there will be a number for it*/
		printf("DIAGNOSTIC: callsign is flying straight and level. \n");

}

void dl()
{
		oneplane k = {"", 7, 7, 30000, 50000, 0, 1986, 320}; 
		
		if(k.alt > 20500)
		{
			k.deg = heading(k.deg - 15);
			printf("DIAGNOSTIC: Descendleft is turning left ");
		}
		else
		{
			printf("DIAGNOSTIC: Descendleft is flying straight ");
		}
		if(k.alt > 19500)
		{
			k.roc = -400;
			printf("and descending. \n");
		}
		else
		{
			k.roc = 0;
			printf("and leveled off. \n");
		}
		
}
void cr()
{
		oneplane k = {"", 7, 7, 35000, 50000, 0, 1986, 320};

		if(k.alt > 30500)
		{
			k.deg = heading(k.deg + 15);
			printf("DIAGNOSTIC: ClimbRight is turning right ");
		}
		else
		{
			printf("DIAGNOSTIC: ClimbRight is flying straight ");
		}
		if(k.alt > 33500)
		{
			k.roc = 400;
			printf("and climbing. \n");
		}
		else
		{
			k.roc = 0;
			printf("and leveled off. \n");
		}
}

int main(void)
{
		int planeprofile;
		/* keep this line */
		void (*fp[])()={sl,dl,cr};
		
		for (planeprofile =0; planeprofile < 3; planeprofile++)
		{	/*keep this line but it will be plane -> profile*/
				fp[planeprofile]();
		} 
		
}

