#include <stdio.h>

/* Author: Isaiah Green */

#include "structs.h"

int main(void)
{

		oneplane k;
		int count = 0;

		while(count = (int)scanf("%s %lf %lf %lf %hd %hd %d", k.callsign, &k.x, &k.y, &k.alt, &k.knot, &k.deg, &k.pilot) == 7)
{
		printf("%s %0.0lf %0.0lf %0.0lf %hd %hd %d \n", k.callsign, k.x, k.y, k.alt, k.knot, k.deg, k.pilot);
		
}

}
