#include "libatc.h"
#include <math.h>
#include <stdio.h>

/* Author: Isaiah Green */

int main()
{
		al_initialize();
		al_clear();
		al_refresh();
		getchar();
		al_teardown();
}
