#include <stdio.h>

/* Author: Isaiah Green */

#define maxSign 15 /* max callsign you need*/


int main(void)
{
char callsign[maxSign];
int x, y, alt;
short knots, dirc;
int count;

while(count = (int)scanf("%s %d %d %d %hd %hd", callsign, &x, &y, &alt, &knots, &dirc) == 6)
{
printf("%s %d %d %d %hd %hd \n", callsign, x, y, alt, knots, dirc);
}
}
