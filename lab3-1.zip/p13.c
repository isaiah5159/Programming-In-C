#include <stdio.h>

/* Author: Isaiah Green */
#define maxSign 15 /* max callsign you need*/

typedef struct 
{
		char callsign[maxSign];
		int time, x, y, alt, gx, gy ,knot, deg, fl, rc;

}numericop;

int main(void)
{
		numericop k;
		/*numeric output on plane */
		k.time=0,k.callsign , k.x=1000000, k.y=1000000, k.gx=50, k.gy=7, k.alt=35400, k.fl=355, k.knot = 1396, k.deg = 225;
		fprintf(stderr,"%5ds %14s (%7d, %7d) (%3d, %3d) %5dft FL%3d %4dK H%3d \n",
		 k.time, k.callsign, k.x, k.y, k.gx, k.gy, k.alt, k.fl, k.knot, k.deg);
}
