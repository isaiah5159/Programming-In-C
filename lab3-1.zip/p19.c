#include <stdio.h>
#include <stdlib.h>

/* Author: Isaiah Green */

int storage()
{
	static int count = 0;
	
	return(count ++);
}

int main(void)
{
		printf("The storage has: %d \n", storage());  
		printf("The storage has: %d \n", storage()); 
		printf("The storage has: %d \n", storage()); 

}
