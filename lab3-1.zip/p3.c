#include "libatc.h"
#include <math.h>
#include <stdio.h>

/* Author: Isaiah Green */

main(){}
