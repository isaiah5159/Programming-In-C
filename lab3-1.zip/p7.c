#include <math.h>
#include <stdio.h>

/* Author: Isaiah Green */

int Flightlevel(int alt)
{
		int dig,fl;
		
		dig = alt /1000;
		fl = dig * 10;
		dig = alt % 1000;
		
		if (dig >= 250) fl += 5;
		if (dig >= 750) fl += 5;
		
		return (fl);
}

int main(void)
{

		int altitude,f,digit;

		printf("Please enter the altitude: \n");
		scanf("%d", &altitude);
		printf("altitude = %d\n", altitude);

		printf("flight level = %d\n", Flightlevel(altitude));
}
