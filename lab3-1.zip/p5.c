#include <math.h>
#include <stdio.h>

/* Author: Isaiah Green */

#define Knots2fps 1.687809855643 /* knot feet per second */
#define M_PI 3.14159265359070323846 /* pi */

double Radians(short heading)
{

		return(heading * M_PI/180.0);
}

double fps(short speed)
{

		return(Knots2fps *speed);	
}

double velY(double speed,short head)
{

		double velocity;
		
		velocity = speed *cos(Radians(head));

		printf("The velocity in Y is: %lf\n", velocity);
		return(velocity);
}

double velX(double speed,short head)
{

		double vel;
		
		vel = speed *sin(Radians(head));

		printf("The velocity in X is: %lf\n", vel);
		return(vel);
}

int main(void)
{

		short h, air_speed;

		printf("Please enter the heading(degrees): \n");
		scanf("%hd", &h);
		printf("Heading = %hd\n", h);

		printf("Please enter the airspeed(knots): \n");
		scanf("%hd", &air_speed);
		printf("airspeed = %lf\n", fps(air_speed));

		velY(fps(air_speed), h);
		velX(fps(air_speed), h);
}
