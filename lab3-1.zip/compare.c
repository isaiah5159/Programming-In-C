#include <stdio.h>
#include <math.h>
#include "structs.h"

/* Author: Isaiah Green */

#define MFX (380*5280)/* x boundary for graphics */
#define MFY (280*5280)/* y boundary for graphics */

/* Checks to see if the plane is outside of colorado */
int outside_colorado(void *data)
{
		
		oneplane *jet = data;
		/*as long as the plane is over colorado */
		if (jet -> x >= 0 && jet -> x < MFX && jet -> y >= 0 && jet -> y < MFY)
		{
			/*printf("%s is in colorado \n",jet->callsign);*/
			return(0);
		}
		else
		{
			/*printf("%s is not in colorado \n",jet->callsign);		*/
			return(1);
		}		
}

/* Checks which plane is further west */
int westmost( void *data1, void *data2)
{
		oneplane *jet = data1;
		oneplane *jet2 = data2;
	
		if( jet -> x <= jet2 -> x) 
		{
			/*printf("%s is west of %s \n",jet->callsign,jet2->callsign);*/
			return(1);
		}
		else
		{
			/*printf("%s is NOT west of %s \n",jet->callsign,jet2->callsign);*/
			return(0);
		}
}

/* Checks to which plane is high than the other */
int higher( void *data1, void *data2)
{
		oneplane *jet = data1;
		oneplane *jet2 = data2;

		if( jet -> alt >= jet2 -> alt) 
		{
		/*	printf("%s is high of %s \n",jet->callsign,jet2->callsign);*/
			return(1);
		}
		else
		{
			/* printf("%s is NOT high of %s \n",jet->callsign,jet2->callsign);*/
			return(0);
		}
}

