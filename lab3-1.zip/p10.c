#include "libatc.h"
#include <math.h>
#include <stdio.h>

/* Author: Isaiah Green */

int main()
{

		al_initialize();
		al_clear();
		al_clock(3723);
		/* gx gy callsign fl knots degrees*/
		al_plane(40, 9, "Blackbird71", 455, 2200, 45);
		al_refresh();
		getchar();
		al_teardown();
}
