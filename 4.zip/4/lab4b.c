#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>

/*
    gcc lab4b.c -o lab4b -lpthread -lrt 
    ./lab4b
*/

/*Author: Isaiah Green */

typedef struct
{
    int x;
    char y[5];
} slotA;
typedef struct
{
    int x;
    char y[7];
} slotB;

void *ThreadA();
void *ThreadB();
void *ThreadC();

pthread_t tid[3];
sem_t mutex, ta, tb, tc, af, ae, bf, be;
slotA bufferA[20], tempA;
slotB bufferB[30], tempB;

int main()
{
    int i;

    i = sem_init(&ae, 0, 20);
    i = sem_init(&af, 0, 0);
    i = sem_init(&be, 0, 30);
    i = sem_init(&bf, 0, 0);

    i = pthread_create(&tid[0], NULL, ThreadA, NULL);
    i = pthread_create(&tid[1], NULL, ThreadB, NULL);
    i = pthread_create(&tid[2], NULL, ThreadC, NULL);

    for (i = 0; i < 3; i++) pthread_join(tid[1], NULL);
    pthread_exit(NULL);
}

void *ThreadB()
{
    int i;
    for (i = 0; i < 500; i++)
    {
        sem_wait(&af);

        tempA = bufferA[i % 20];

        sem_post(&ae);

        /*start comsuming item1 and producing item2*/
        tempB.x = tempA.x * 10;
        sprintf(tempB.y, "%sOK", tempA.y);
        /*consuming item1 and producing item2 done*/

        sem_wait(&be);

        bufferB[i % 30] = tempB;

        sem_post(&bf);

        if (i % 75 == 0)
        {
            sleep(0.3);
        }
    }
    pthread_exit(NULL);
}

void *ThreadC()
{
    int i;
    for (i = 0; i < 500; i++)
    {
        sem_wait(&bf);

        /*start consuming itemB*/

        printf("%d%s \n", bufferB[i % 30].x, bufferB[i % 30].y);

        sem_post(&be);
        /*consuming itemB done*/
        if (i % 100 == 0)
        {
            sleep(0.3);
        }
    }
    pthread_exit(NULL);
}

void *ThreadA()
{
    int i;
    /*start produce*/
    for (i = 0; i < 500; i++)
    {
        sem_wait(&ae);

        if (i % 2 == 0)
        {
            sprintf(bufferA[i % 20].y, "Besta");
        }
        else
        {
            sprintf(bufferA[i % 20].y, "Hello");
        }
        /* an itemA produced*/
        bufferA[i % 20].x = i + 1;

        sem_post(&af);

        if (i % 100 == 0)
        {
            sleep(0.3);
        }
    }
    pthread_exit(NULL);
}
