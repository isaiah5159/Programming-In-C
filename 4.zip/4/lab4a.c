#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>

/* 
    gcc lab4a.c -o lab4a -lpthread -lrt
    ./lab4a
*/

/*Author: Isaiah Green */

void *Thread1();
void *Thread2();
void *Thread3();
void *Thread4();

pthread_t tid[4];
sem_t mutex, t1, t2, t3, t4;
int Account[3];

int main()
{
  Account[0] = 100000;
  Account[1] = 100000;
  Account[2] = 100000;

  sem_init(&mutex, 0, 1);
  sem_init(&t1, 0, 0);
  sem_init(&t2, 0, 0);
  sem_init(&t3, 0, 0);
  sem_init(&t4, 0, 0);

  pthread_create(&tid[0], NULL, Thread1, NULL);
  pthread_create(&tid[1], NULL, Thread2, NULL);
  pthread_create(&tid[2], NULL, Thread3, NULL);
  pthread_create(&tid[3], NULL, Thread4, NULL);
  pthread_join(tid[1], NULL);
  pthread_exit(NULL);
}

void *Thread1()
{
  int i, internal_reg, a, b, c;

  /*synch. with Thread2, Thread3 & Thread4 (4 proc 4 way synch.)*/
  sem_post(&t1);
  sem_post(&t1);
  sem_post(&t1);
  sem_wait(&t2);
  sem_wait(&t3);
  sem_wait(&t4);

  for (i = 0; i < 10000; i++)
  {
    sem_wait(&mutex);

    internal_reg = Account[0];

    internal_reg = internal_reg - 200;

    Account[0] = internal_reg;

    /* same thing, except we're adding $200 to account1 now... */

    internal_reg = Account[1];

    internal_reg = internal_reg + 200;

    Account[1] = internal_reg;

    a = Account[0];
    b = Account[1];
    c = Account[2];

    /* here add a code that outputs contents of each account and

        their sum after 1,000th, 2,000th, 3,000th, .... and 10,000th iteration*/

    sem_post(&mutex);

    if (i % 1000 == 0)
    {
      printf("thread1 %dth transaction\n", i);
      printf("Money in account0 is :%d\n", a);
      printf("Money in account1 is :%d\n", b);
      printf("Money in account2 is :%d\n", c);
      printf("thread1 sum is: %d\n", a + b + c);
      printf("\n");
    }
    if (i % 3000 == 0)
    {
      sleep(0.2);
    }
  }
  sem_post(&t1);
  pthread_exit(NULL);
  /* above include some wait and signal ops on semaphores. Do not over-synchronize. */
}

void *Thread2()
{
  int i, internal_reg, a, b, c;

  /*synch. with Thread2, Thread3 & Thread4 (4 proc 4 way synch.)*/
  sem_post(&t2);
  sem_post(&t2);
  sem_post(&t2);
  sem_wait(&t1);
  sem_wait(&t3);
  sem_wait(&t4);

  for (i = 0; i < 10000; i++)
  {
    sem_wait(&mutex);

    internal_reg = Account[1];

    internal_reg = internal_reg - 200;

    Account[1] = internal_reg;

    /* same thing, except we're adding $200 to account1 now... */

    internal_reg = Account[2];

    internal_reg = internal_reg + 200;

    Account[2] = internal_reg;

    a = Account[0];
    b = Account[1];
    c = Account[2];

    /* here add a code that outputs contents of each account and

        their sum after 1,000th, 2,000th, 3,000th, .... and 10,000th iteration*/

    sem_post(&mutex);
    if (i % 1000 == 0)
    {
      printf("thread2 %dth transaction\n", i);
      printf("Money in account0 is :%d\n", a);
      printf("Money in account1 is :%d\n", b);
      printf("Money in account2 is :%d\n", c);
      printf("thread2 sum is: %d\n", a + b + c);
      printf("\n");
    }
    if (i % 2000 == 0)
    {
      sleep(0.2);
    }
  }
  sem_post(&t2);
  pthread_exit(NULL);
  /* above include some wait and signal ops on semaphores. Do not over-synchronize. */
}

void *Thread3()
{
  int i, internal_reg, a, b, c;

  /*synch. with Thread2, Thread3 & Thread4 (4 proc 4 way synch.)*/
  sem_post(&t3);
  sem_post(&t3);
  sem_post(&t3);
  sem_wait(&t1);
  sem_wait(&t2);
  sem_wait(&t4);

  for (i = 0; i < 10000; i++)
  {
    sem_wait(&mutex);

    internal_reg = Account[2];

    internal_reg = internal_reg - 200;

    Account[2] = internal_reg;

    /* same thing, except we're adding $200 to account1 now... */

    internal_reg = Account[0];

    internal_reg = internal_reg + 200;

    Account[0] = internal_reg;

    a = Account[0];
    b = Account[1];
    c = Account[2];

    /* here add a code that outputs contents of each account and

        their sum after 1,000th, 2,000th, 3,000th, .... and 10,000th iteration*/
    sem_post(&mutex);

    if (i % 1000 == 0)
    {
      printf("thread3 %dth transaction\n", i);
      printf("Money in account0 is :%d\n", a);
      printf("Money in account1 is :%d\n", b);
      printf("Money in account2 is :%d\n", c);
      printf("thread3 sum is: %d\n", a + b + c);
      printf("\n");
    }
    if (i % 3000 == 0)
    {
      sleep(0.3);
    }
    else if (i % 7500 == 0)
    {
      sleep(0.3);
    }
  }
  sem_post(&t3);

  pthread_exit(NULL);
  /* above include some wait and signal ops on semaphores. Do not over-synchronize. */
}

void *Thread4()
{
  int sum, i;
  //synchronize with Proc1, Proc2 & Proc3 (4 process 4 way sync.)
  sem_post(&t4);
  sem_post(&t4);
  sem_post(&t4);
  sem_wait(&t1);
  sem_wait(&t2);
  sem_wait(&t3);

  for (i = 0; i < 50000; i++)
  {
    sem_wait(&mutex);
    sum = Account[0] + Account[1] + Account[2];
    sem_post(&mutex);

    if (sum != 300000)
    {
      printf("Thread4 when not 300000 %dth transaction\n", i);
    }
    if (i % 10000 == 0)
    {
      sleep(0.05);
    }
  }
  printf("This is the number of times sum was checked %d\n", i);

  sem_wait(&t1);
  sem_wait(&t2);
  sem_wait(&t3);

  exit(0);
}
